create view pg_matviews (schemaname, matviewname, matviewowner, tablespace, hasindexes, ispopulated, definition) as
select n.nspname as schemaname,
  c.relname as matviewname,
  pg_get_userbyid(c.relowner) as matviewowner,
  t.spcname as tablespace,
  c.relhasindex as hasindexes,
  c.relispopulated as ispopulated,
  pg_get_viewdef(c.oid) as definition
from
  pg_class c
    left join pg_namespace n on n.oid = c.relnamespace
    left join pg_tablespace t on t.oid = c.reltablespace
where c.relkind = 'm'::"char";

alter table pg_matviews
  owner to postgres;

grant select on pg_matviews to public;

