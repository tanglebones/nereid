create view pg_stat_user_functions(funcid, schemaname, funcname, calls, total_time, self_time) as
select p.oid as funcid,
  n.nspname as schemaname,
  p.proname as funcname,
  pg_stat_get_function_calls(p.oid) as calls,
  pg_stat_get_function_total_time(p.oid) as total_time,
  pg_stat_get_function_self_time(p.oid) as self_time
from
  pg_proc p
    left join pg_namespace n on n.oid = p.pronamespace
where p.prolang <> 12::oid and pg_stat_get_function_calls(p.oid) is not null;

alter table pg_stat_user_functions
  owner to postgres;

grant select on pg_stat_user_functions to public;

