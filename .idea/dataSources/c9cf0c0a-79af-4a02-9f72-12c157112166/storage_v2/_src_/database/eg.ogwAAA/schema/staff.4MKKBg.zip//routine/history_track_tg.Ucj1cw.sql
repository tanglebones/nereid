create function history_track_tg() returns trigger
  language plpgsql
as
$$
declare
  who varchar;
  tx bigint;
  newhs hstore;
  oldhs hstore;
  idname varchar;
  id uuid;
begin
  select current_setting('audit.user')
  into who;

  if who is null or who = ''
  then
    raise exception 'audit.user is not set.';
  end if;

  idname = tg_argv[0];

  tx = pg_current_xact_id();

  if tg_op = 'UPDATE'
  then
    oldhs = hstore(old);
    newhs = hstore(new);
    if ((oldhs -> idname) != (newhs -> idname))
    then
      raise exception 'id cannot be changed';
    end if;

    id = (newhs -> idname) :: uuid;
    -- RAISE NOTICE '%', id;
    insert
    into
      history (id, schema_name, table_name, tx, who, op, entry)
    values (id, tg_table_schema, tg_table_name, tx, who, 'U', oldhs - newhs);
    return new;
  end if;

  if tg_op = 'INSERT'
  then
    newhs = hstore(new);
    id = (newhs -> idname) :: uuid;
    -- RAISE NOTICE '%', id;
    insert
    into
      history (id, schema_name, table_name, tx, who, op, entry)
    values (id, tg_table_schema, tg_table_name, tx, who, 'I', ''::hstore);
    return new;
  end if;

  if tg_op = 'DELETE'
  then
    oldhs = hstore(old);
    id = (oldhs -> idname) :: uuid;
    -- RAISE NOTICE '%', id;
    insert
    into
      history (id, schema_name, table_name, tx, who, op, entry)
    values (id, tg_table_schema, tg_table_name, tx, who, 'D', oldhs);
    return old;
  end if;

  return null;
end;
$$;

alter function history_track_tg() owner to eg_dba;

