create view pg_publication_tables(pubname, schemaname, tablename) as
select p.pubname,
  n.nspname as schemaname,
  c.relname as tablename
from
  pg_publication p,
  lateral pg_get_publication_tables(p.pubname::text) gpt(relid),
  pg_class c
  join pg_namespace n on n.oid = c.relnamespace
where c.oid = gpt.relid;

alter table pg_publication_tables
  owner to postgres;

grant select on pg_publication_tables to public;

