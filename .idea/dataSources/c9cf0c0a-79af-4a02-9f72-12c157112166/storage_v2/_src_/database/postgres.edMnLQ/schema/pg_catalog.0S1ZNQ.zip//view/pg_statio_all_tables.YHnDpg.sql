create view pg_statio_all_tables
    (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
     toast_blks_hit, tidx_blks_read, tidx_blks_hit)
as
select c.oid as relid,
  n.nspname as schemaname,
  c.relname,
  pg_stat_get_blocks_fetched(c.oid) - pg_stat_get_blocks_hit(c.oid) as heap_blks_read,
  pg_stat_get_blocks_hit(c.oid) as heap_blks_hit,
  sum(pg_stat_get_blocks_fetched(i.indexrelid) - pg_stat_get_blocks_hit(i.indexrelid))::bigint as idx_blks_read,
  sum(pg_stat_get_blocks_hit(i.indexrelid))::bigint as idx_blks_hit,
  pg_stat_get_blocks_fetched(t.oid) - pg_stat_get_blocks_hit(t.oid) as toast_blks_read,
  pg_stat_get_blocks_hit(t.oid) as toast_blks_hit,
  pg_stat_get_blocks_fetched(x.indexrelid) - pg_stat_get_blocks_hit(x.indexrelid) as tidx_blks_read,
  pg_stat_get_blocks_hit(x.indexrelid) as tidx_blks_hit
from
  pg_class c
    left join pg_index i on c.oid = i.indrelid
    left join pg_class t on c.reltoastrelid = t.oid
    left join pg_index x on t.oid = x.indrelid
    left join pg_namespace n on n.oid = c.relnamespace
where c.relkind = any (array ['r'::"char", 't'::"char", 'm'::"char"])
group by c.oid, n.nspname, c.relname, t.oid, x.indexrelid;

alter table pg_statio_all_tables
  owner to postgres;

grant select on pg_statio_all_tables to public;

