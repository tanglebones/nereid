create view pg_sequences
    (schemaname, sequencename, sequenceowner, data_type, start_value, min_value, max_value, increment_by, cycle,
     cache_size, last_value)
as
select n.nspname as schemaname,
  c.relname as sequencename,
  pg_get_userbyid(c.relowner) as sequenceowner,
  s.seqtypid::regtype as data_type,
  s.seqstart as start_value,
  s.seqmin as min_value,
  s.seqmax as max_value,
  s.seqincrement as increment_by,
  s.seqcycle as cycle,
  s.seqcache as cache_size,
  case
    when has_sequence_privilege(c.oid, 'SELECT,USAGE'::text) then pg_sequence_last_value(c.oid::regclass)
    else null::bigint
    end as last_value
from
  pg_sequence s
    join pg_class c on c.oid = s.seqrelid
    left join pg_namespace n on n.oid = c.relnamespace
where not pg_is_other_temp_schema(n.oid) and c.relkind = 'S'::"char";

alter table pg_sequences
  owner to postgres;

grant select on pg_sequences to public;

