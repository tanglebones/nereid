create function max(uuid, uuid) returns uuid
  language plpgsql
as
$$
begin
  if $1 is null and $2 is null
  then
    return null;
  end if;

  if $1 is null
  then
    return $2;
  end if;

  if $2 is null
  then
    return $1;
  end if;

  if $1 < $2 then
    return $2;
  end if;

  return $1;
end;
$$;

alter function max(uuid, uuid) owner to eg_test_dba;

grant execute on function max(uuid, uuid) to eg_test_app;

grant execute on function max(uuid, uuid) to eg_test_ro_app;

grant execute on function max(uuid, uuid) to eg_test_staff;

grant execute on function max(uuid, uuid) to eg_test_ro_staff;

