create function app_session_ivkey_assign() returns trigger
  security definer
  language plpgsql
as
$$
declare
  ivkey_ bytea;
begin
  if new.login_id is null then
    new.ivkey = null;
    return new;
  end if;

  insert
  into
    staff.app_login_1_ivkey (app_login_id, ivkey)
  values (new.login_id, func.gen_random_bytes(48))
  on conflict do nothing;

  select ivkey into ivkey_ from staff.app_login_1_ivkey where app_login_id = new.login_id;
  new.ivkey = ivkey_;
  return new;
end;
$$;

alter function app_session_ivkey_assign() owner to eg_test_staff;

grant execute on function app_session_ivkey_assign() to eg_test_app;

grant execute on function app_session_ivkey_assign() to eg_test_ro_app;

grant execute on function app_session_ivkey_assign() to eg_test_ro_staff;

