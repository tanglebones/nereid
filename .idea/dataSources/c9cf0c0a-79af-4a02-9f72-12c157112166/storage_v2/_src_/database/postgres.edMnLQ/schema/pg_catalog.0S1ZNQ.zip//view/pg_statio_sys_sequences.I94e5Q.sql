create view pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) as
select pg_statio_all_sequences.relid,
  pg_statio_all_sequences.schemaname,
  pg_statio_all_sequences.relname,
  pg_statio_all_sequences.blks_read,
  pg_statio_all_sequences.blks_hit
from pg_statio_all_sequences
where (pg_statio_all_sequences.schemaname = any (array ['pg_catalog'::name, 'information_schema'::name]))
   or pg_statio_all_sequences.schemaname ~ '^pg_toast'::text;

alter table pg_statio_sys_sequences
  owner to postgres;

grant select on pg_statio_sys_sequences to public;

