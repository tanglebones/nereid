create function aes_decrypt_to_numeric(ivkey bytea, what bytea) returns numeric
  language sql
as
$$
select encode(
  decrypt_iv(
    what,
    substring(ivkey::bytea, 1, 32),
    substring(ivkey::bytea, 33, 16),
    'AES'
    ),
  'escape') :: numeric
$$;

alter function aes_decrypt_to_numeric(bytea, bytea) owner to eg_dba;

grant execute on function aes_decrypt_to_numeric(bytea, bytea) to eg_app;

grant execute on function aes_decrypt_to_numeric(bytea, bytea) to eg_ro_app;

grant execute on function aes_decrypt_to_numeric(bytea, bytea) to eg_staff;

grant execute on function aes_decrypt_to_numeric(bytea, bytea) to eg_ro_staff;

