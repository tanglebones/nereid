create view pg_statio_all_sequences(relid, schemaname, relname, blks_read, blks_hit) as
select c.oid as relid,
  n.nspname as schemaname,
  c.relname,
  pg_stat_get_blocks_fetched(c.oid) - pg_stat_get_blocks_hit(c.oid) as blks_read,
  pg_stat_get_blocks_hit(c.oid) as blks_hit
from
  pg_class c
    left join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'S'::"char";

alter table pg_statio_all_sequences
  owner to postgres;

grant select on pg_statio_all_sequences to public;

