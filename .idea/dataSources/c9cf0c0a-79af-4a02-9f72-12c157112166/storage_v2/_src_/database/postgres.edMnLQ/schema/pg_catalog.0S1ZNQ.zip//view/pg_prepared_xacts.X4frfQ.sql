create view pg_prepared_xacts(transaction, gid, prepared, owner, database) as
select p.transaction,
  p.gid,
  p.prepared,
  u.rolname as owner,
  d.datname as database
from
  pg_prepared_xact() p(transaction, gid, prepared, ownerid, dbid)
    left join pg_authid u on p.ownerid = u.oid
    left join pg_database d on p.dbid = d.oid;

alter table pg_prepared_xacts
  owner to postgres;

grant select on pg_prepared_xacts to public;

