create function stuid_tz(stuid bytea) returns timestamp with time zone
  language sql
as
$$
select
  case
    when stuid is null
      then null
    else
      ('x' || substr(stuid::text, 1, 12))::bit(64)::bigint * interval '1 millisecond' + timestamptz 'epoch'
    end;
$$;

alter function stuid_tz(bytea) owner to eg_dba;

grant execute on function stuid_tz(bytea) to eg_app;

grant execute on function stuid_tz(bytea) to eg_ro_app;

grant execute on function stuid_tz(bytea) to eg_staff;

grant execute on function stuid_tz(bytea) to eg_ro_staff;

