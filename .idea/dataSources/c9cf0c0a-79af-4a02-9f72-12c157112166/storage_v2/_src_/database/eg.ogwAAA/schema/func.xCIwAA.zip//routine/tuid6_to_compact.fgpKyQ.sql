create function tuid6_to_compact(tuid uuid) returns character varying
  language sql
as
$$
select
  case
    when tuid is null
      then null
    else
      replace(translate(encode(decode(replace(tuid::text, '-', ''), 'hex'), 'base64'), '/+', '-_'), '=', '')
    end;
$$;

alter function tuid6_to_compact(uuid) owner to eg_dba;

grant execute on function tuid6_to_compact(uuid) to eg_app;

grant execute on function tuid6_to_compact(uuid) to eg_ro_app;

grant execute on function tuid6_to_compact(uuid) to eg_staff;

grant execute on function tuid6_to_compact(uuid) to eg_ro_staff;

