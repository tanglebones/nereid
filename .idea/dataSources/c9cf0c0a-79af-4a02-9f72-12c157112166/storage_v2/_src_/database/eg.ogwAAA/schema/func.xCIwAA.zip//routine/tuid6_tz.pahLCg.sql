create function tuid6_tz(tuid uuid) returns timestamp with time zone
  language sql
as
$$
with
  t as (
    select tuid::varchar as x
  )
select
  case
    when tuid is null
      then null
    else (
      'x'
          || substr(t.x, 1, 8) -- xxxxxxxx-0000-0000-0000-000000000000
          || substr(t.x, 10, 4) -- 00000000-xxxx-0000-0000-000000000000
      )::bit(64)::bigint * interval '1 millisecond' + timestamptz 'epoch'
    end
from
  t;
$$;

alter function tuid6_tz(uuid) owner to eg_dba;

grant execute on function tuid6_tz(uuid) to eg_app;

grant execute on function tuid6_tz(uuid) to eg_ro_app;

grant execute on function tuid6_tz(uuid) to eg_staff;

grant execute on function tuid6_tz(uuid) to eg_ro_staff;

