create function aes_encrypt(ivkey bytea, what text) returns bytea
  language sql
as
$$
select encrypt_iv(
  decode(what, 'escape'),
  substring(ivkey::bytea, 1, 32),
  substring(ivkey::bytea, 33, 16),
  'AES'
  )
$$;

alter function aes_encrypt(bytea, text) owner to eg_dba;

grant execute on function aes_encrypt(bytea, text) to eg_app;

grant execute on function aes_encrypt(bytea, text) to eg_ro_app;

grant execute on function aes_encrypt(bytea, text) to eg_staff;

grant execute on function aes_encrypt(bytea, text) to eg_ro_staff;

