create function add_history_to_table(table_name character varying, id_column_name character varying DEFAULT NULL::character varying) returns void
  language plpgsql
as
$$
BEGIN
    IF id_column_name IS NULL
    THEN
      id_column_name = table_name || '_id';
    END IF;

    -- hook up the trigger
    EXECUTE FORMAT(
      'CREATE TRIGGER %I
        AFTER UPDATE OR DELETE OR INSERT
        ON staff.%I
        FOR EACH ROW EXECUTE PROCEDURE staff.history_track_tg(%L);
      ',
      table_name || '_history',
      table_name,
      id_column_name
      );
  END;
$$;

alter function add_history_to_table(varchar, varchar) owner to eg_test_dba;

