create function tuid6_to_compact(tuid uuid) returns character varying
  language sql
as
$$
select replace(translate(encode(decode(replace(tuid::text, '-', ''), 'hex'), 'base64'), '/+', '-_'), '=', '');
$$;

alter function tuid6_to_compact(uuid) owner to eg_test_dba;

grant execute on function tuid6_to_compact(uuid) to eg_test_app;

grant execute on function tuid6_to_compact(uuid) to eg_test_ro_app;

grant execute on function tuid6_to_compact(uuid) to eg_test_staff;

grant execute on function tuid6_to_compact(uuid) to eg_test_ro_staff;

