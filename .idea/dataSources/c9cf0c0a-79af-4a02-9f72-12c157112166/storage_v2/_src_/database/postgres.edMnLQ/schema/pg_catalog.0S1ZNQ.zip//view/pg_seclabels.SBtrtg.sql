create view pg_seclabels (objoid, classoid, objsubid, objtype, objnamespace, objname, provider, label) as
select l.objoid,
  l.classoid,
  l.objsubid,
  case
    when rel.relkind = any (array ['r'::"char", 'p'::"char"]) then 'table'::text
    when rel.relkind = 'v'::"char" then 'view'::text
    when rel.relkind = 'm'::"char" then 'materialized view'::text
    when rel.relkind = 'S'::"char" then 'sequence'::text
    when rel.relkind = 'f'::"char" then 'foreign table'::text
    else null::text
    end as objtype,
  rel.relnamespace as objnamespace,
  case
    when pg_table_is_visible(rel.oid) then quote_ident(rel.relname::text)
    else (quote_ident(nsp.nspname::text) || '.'::text) || quote_ident(rel.relname::text)
    end as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_class rel on l.classoid = rel.tableoid and l.objoid = rel.oid
    join pg_namespace nsp on rel.relnamespace = nsp.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'column'::text as objtype,
  rel.relnamespace as objnamespace,
  (
    case
      when pg_table_is_visible(rel.oid) then quote_ident(rel.relname::text)
      else (quote_ident(nsp.nspname::text) || '.'::text) || quote_ident(rel.relname::text)
      end || '.'::text) || att.attname::text as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_class rel on l.classoid = rel.tableoid and l.objoid = rel.oid
    join pg_attribute att on rel.oid = att.attrelid and l.objsubid = att.attnum
    join pg_namespace nsp on rel.relnamespace = nsp.oid
where l.objsubid <> 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  case pro.prokind
    when 'a'::"char" then 'aggregate'::text
    when 'f'::"char" then 'function'::text
    when 'p'::"char" then 'procedure'::text
    when 'w'::"char" then 'window'::text
    else null::text
    end as objtype,
  pro.pronamespace as objnamespace,
  ((
    case
      when pg_function_is_visible(pro.oid) then quote_ident(pro.proname::text)
      else (quote_ident(nsp.nspname::text) || '.'::text) || quote_ident(pro.proname::text)
      end || '('::text) || pg_get_function_arguments(pro.oid)) || ')'::text as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_proc pro on l.classoid = pro.tableoid and l.objoid = pro.oid
    join pg_namespace nsp on pro.pronamespace = nsp.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  case
    when typ.typtype = 'd'::"char" then 'domain'::text
    else 'type'::text
    end as objtype,
  typ.typnamespace as objnamespace,
  case
    when pg_type_is_visible(typ.oid) then quote_ident(typ.typname::text)
    else (quote_ident(nsp.nspname::text) || '.'::text) || quote_ident(typ.typname::text)
    end as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_type typ on l.classoid = typ.tableoid and l.objoid = typ.oid
    join pg_namespace nsp on typ.typnamespace = nsp.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'large object'::text as objtype,
  null::oid as objnamespace,
  l.objoid::text as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_largeobject_metadata lom on l.objoid = lom.oid
where l.classoid = 'pg_largeobject'::regclass::oid and l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'language'::text as objtype,
  null::oid as objnamespace,
  quote_ident(lan.lanname::text) as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_language lan on l.classoid = lan.tableoid and l.objoid = lan.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'schema'::text as objtype,
  nsp.oid as objnamespace,
  quote_ident(nsp.nspname::text) as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_namespace nsp on l.classoid = nsp.tableoid and l.objoid = nsp.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'event trigger'::text as objtype,
  null::oid as objnamespace,
  quote_ident(evt.evtname::text) as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_event_trigger evt on l.classoid = evt.tableoid and l.objoid = evt.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  l.objsubid,
  'publication'::text as objtype,
  null::oid as objnamespace,
  quote_ident(p.pubname::text) as objname,
  l.provider,
  l.label
from
  pg_seclabel l
    join pg_publication p on l.classoid = p.tableoid and l.objoid = p.oid
where l.objsubid = 0
union all
select l.objoid,
  l.classoid,
  0 as objsubid,
  'subscription'::text as objtype,
  null::oid as objnamespace,
  quote_ident(s.subname::text) as objname,
  l.provider,
  l.label
from
  pg_shseclabel l
    join pg_subscription s on l.classoid = s.tableoid and l.objoid = s.oid
union all
select l.objoid,
  l.classoid,
  0 as objsubid,
  'database'::text as objtype,
  null::oid as objnamespace,
  quote_ident(dat.datname::text) as objname,
  l.provider,
  l.label
from
  pg_shseclabel l
    join pg_database dat on l.classoid = dat.tableoid and l.objoid = dat.oid
union all
select l.objoid,
  l.classoid,
  0 as objsubid,
  'tablespace'::text as objtype,
  null::oid as objnamespace,
  quote_ident(spc.spcname::text) as objname,
  l.provider,
  l.label
from
  pg_shseclabel l
    join pg_tablespace spc on l.classoid = spc.tableoid and l.objoid = spc.oid
union all
select l.objoid,
  l.classoid,
  0 as objsubid,
  'role'::text as objtype,
  null::oid as objnamespace,
  quote_ident(rol.rolname::text) as objname,
  l.provider,
  l.label
from
  pg_shseclabel l
    join pg_authid rol on l.classoid = rol.tableoid and l.objoid = rol.oid;

alter table pg_seclabels
  owner to postgres;

grant select on pg_seclabels to public;

