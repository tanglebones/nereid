create function stuid_from_compact(compact character varying) returns bytea
  language sql
as
$$
select decode(rpad(translate(compact, '-_', '/+'), 24, '='), 'base64');
$$;

alter function stuid_from_compact(varchar) owner to eg_test_dba;

grant execute on function stuid_from_compact(varchar) to eg_test_app;

grant execute on function stuid_from_compact(varchar) to eg_test_ro_app;

grant execute on function stuid_from_compact(varchar) to eg_test_staff;

grant execute on function stuid_from_compact(varchar) to eg_test_ro_staff;

