create function tuid6_from_compact(compact character varying) returns uuid
  language sql
as
$$
select encode(decode(rpad(translate(compact, '-_', '/+'), 24, '='), 'base64'), 'hex')::uuid;
$$;

alter function tuid6_from_compact(varchar) owner to eg_dba;

grant execute on function tuid6_from_compact(varchar) to eg_app;

grant execute on function tuid6_from_compact(varchar) to eg_ro_app;

grant execute on function tuid6_from_compact(varchar) to eg_staff;

grant execute on function tuid6_from_compact(varchar) to eg_ro_staff;

