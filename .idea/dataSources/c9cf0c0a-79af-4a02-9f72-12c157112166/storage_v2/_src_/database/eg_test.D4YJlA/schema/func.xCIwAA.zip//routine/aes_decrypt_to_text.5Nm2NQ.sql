create function aes_decrypt_to_text(ivkey bytea, what bytea) returns text
  language sql
as
$$
select encode(
  decrypt_iv(
    what,
    substring(ivkey::bytea, 1, 32),
    substring(ivkey::bytea, 33, 16),
    'AES'
    ),
  'escape')
$$;

alter function aes_decrypt_to_text(bytea, bytea) owner to eg_test_dba;

grant execute on function aes_decrypt_to_text(bytea, bytea) to eg_test_app;

grant execute on function aes_decrypt_to_text(bytea, bytea) to eg_test_ro_app;

grant execute on function aes_decrypt_to_text(bytea, bytea) to eg_test_staff;

grant execute on function aes_decrypt_to_text(bytea, bytea) to eg_test_ro_staff;

