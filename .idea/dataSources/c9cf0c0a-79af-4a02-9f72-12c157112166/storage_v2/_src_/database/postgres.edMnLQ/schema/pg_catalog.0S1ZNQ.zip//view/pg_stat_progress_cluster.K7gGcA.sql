create view pg_stat_progress_cluster
    (pid, datid, datname, relid, command, phase, cluster_index_relid, heap_tuples_scanned, heap_tuples_written,
     heap_blks_total, heap_blks_scanned, index_rebuild_count)
as
select s.pid,
  s.datid,
  d.datname,
  s.relid,
  case s.param1
    when 1 then 'CLUSTER'::text
    when 2 then 'VACUUM FULL'::text
    else null::text
    end as command,
  case s.param2
    when 0 then 'initializing'::text
    when 1 then 'seq scanning heap'::text
    when 2 then 'index scanning heap'::text
    when 3 then 'sorting tuples'::text
    when 4 then 'writing new heap'::text
    when 5 then 'swapping relation files'::text
    when 6 then 'rebuilding index'::text
    when 7 then 'performing final cleanup'::text
    else null::text
    end as phase,
  s.param3::oid as cluster_index_relid,
  s.param4 as heap_tuples_scanned,
  s.param5 as heap_tuples_written,
  s.param6 as heap_blks_total,
  s.param7 as heap_blks_scanned,
  s.param8 as index_rebuild_count
from
  pg_stat_get_progress_info('CLUSTER'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                               param7, param8, param9, param10, param11, param12, param13, param14,
                                               param15, param16, param17, param18, param19, param20)
    left join pg_database d on s.datid = d.oid;

alter table pg_stat_progress_cluster
  owner to postgres;

grant select on pg_stat_progress_cluster to public;

