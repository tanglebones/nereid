create view pg_stats_ext
    (schemaname, tablename, statistics_schemaname, statistics_name, statistics_owner, attnames, exprs, kinds,
     n_distinct, dependencies, most_common_vals, most_common_val_nulls, most_common_freqs, most_common_base_freqs)
as
select cn.nspname as schemaname,
  c.relname as tablename,
  sn.nspname as statistics_schemaname,
  s.stxname as statistics_name,
  pg_get_userbyid(s.stxowner) as statistics_owner,
  (select array_agg(a.attname order by a.attnum) as array_agg
   from
     unnest(s.stxkeys) k(k)
       join pg_attribute a on a.attrelid = s.stxrelid and a.attnum = k.k) as attnames,
  pg_get_statisticsobjdef_expressions(s.oid) as exprs,
  s.stxkind as kinds,
  sd.stxdndistinct as n_distinct,
  sd.stxddependencies as dependencies,
  m.most_common_vals,
  m.most_common_val_nulls,
  m.most_common_freqs,
  m.most_common_base_freqs
from
  pg_statistic_ext s
    join pg_class c on c.oid = s.stxrelid
    join pg_statistic_ext_data sd on s.oid = sd.stxoid
    left join pg_namespace cn on cn.oid = c.relnamespace
    left join pg_namespace sn on sn.oid = s.stxnamespace
    left join lateral ( select array_agg(pg_mcv_list_items."values") as most_common_vals,
                          array_agg(pg_mcv_list_items.nulls) as most_common_val_nulls,
                          array_agg(pg_mcv_list_items.frequency) as most_common_freqs,
                          array_agg(pg_mcv_list_items.base_frequency) as most_common_base_freqs
                        from
                          pg_mcv_list_items(sd.stxdmcv) pg_mcv_list_items(index, "values", nulls, frequency, base_frequency)) m
              on sd.stxdmcv is not null
where not (exists(select 1
                  from
                    unnest(s.stxkeys) k(k)
                      join pg_attribute a on a.attrelid = s.stxrelid and a.attnum = k.k
                  where not has_column_privilege(c.oid, a.attnum, 'select'::text)))
  and (c.relrowsecurity = false or not row_security_active(c.oid));

alter table pg_stats_ext
  owner to postgres;

grant select on pg_stats_ext to public;

