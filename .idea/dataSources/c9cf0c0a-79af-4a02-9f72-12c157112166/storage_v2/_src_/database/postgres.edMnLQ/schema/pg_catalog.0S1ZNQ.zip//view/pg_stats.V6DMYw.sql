create view pg_stats
    (schemaname, tablename, attname, inherited, null_frac, avg_width, n_distinct, most_common_vals, most_common_freqs,
     histogram_bounds, correlation, most_common_elems, most_common_elem_freqs, elem_count_histogram)
as
select n.nspname as schemaname,
  c.relname as tablename,
  a.attname,
  s.stainherit as inherited,
  s.stanullfrac as null_frac,
  s.stawidth as avg_width,
  s.stadistinct as n_distinct,
  case
    when s.stakind1 = 1 then s.stavalues1
    when s.stakind2 = 1 then s.stavalues2
    when s.stakind3 = 1 then s.stavalues3
    when s.stakind4 = 1 then s.stavalues4
    when s.stakind5 = 1 then s.stavalues5
    else null::anyarray
    end as most_common_vals,
  case
    when s.stakind1 = 1 then s.stanumbers1
    when s.stakind2 = 1 then s.stanumbers2
    when s.stakind3 = 1 then s.stanumbers3
    when s.stakind4 = 1 then s.stanumbers4
    when s.stakind5 = 1 then s.stanumbers5
    else null::real[]
    end as most_common_freqs,
  case
    when s.stakind1 = 2 then s.stavalues1
    when s.stakind2 = 2 then s.stavalues2
    when s.stakind3 = 2 then s.stavalues3
    when s.stakind4 = 2 then s.stavalues4
    when s.stakind5 = 2 then s.stavalues5
    else null::anyarray
    end as histogram_bounds,
  case
    when s.stakind1 = 3 then s.stanumbers1[1]
    when s.stakind2 = 3 then s.stanumbers2[1]
    when s.stakind3 = 3 then s.stanumbers3[1]
    when s.stakind4 = 3 then s.stanumbers4[1]
    when s.stakind5 = 3 then s.stanumbers5[1]
    else null::real
    end as correlation,
  case
    when s.stakind1 = 4 then s.stavalues1
    when s.stakind2 = 4 then s.stavalues2
    when s.stakind3 = 4 then s.stavalues3
    when s.stakind4 = 4 then s.stavalues4
    when s.stakind5 = 4 then s.stavalues5
    else null::anyarray
    end as most_common_elems,
  case
    when s.stakind1 = 4 then s.stanumbers1
    when s.stakind2 = 4 then s.stanumbers2
    when s.stakind3 = 4 then s.stanumbers3
    when s.stakind4 = 4 then s.stanumbers4
    when s.stakind5 = 4 then s.stanumbers5
    else null::real[]
    end as most_common_elem_freqs,
  case
    when s.stakind1 = 5 then s.stanumbers1
    when s.stakind2 = 5 then s.stanumbers2
    when s.stakind3 = 5 then s.stanumbers3
    when s.stakind4 = 5 then s.stanumbers4
    when s.stakind5 = 5 then s.stanumbers5
    else null::real[]
    end as elem_count_histogram
from
  pg_statistic s
    join pg_class c on c.oid = s.starelid
    join pg_attribute a on c.oid = a.attrelid and a.attnum = s.staattnum
    left join pg_namespace n on n.oid = c.relnamespace
where not a.attisdropped and has_column_privilege(c.oid, a.attnum, 'select'::text)
  and (c.relrowsecurity = false or not row_security_active(c.oid));

alter table pg_stats
  owner to postgres;

grant select on pg_stats to public;

