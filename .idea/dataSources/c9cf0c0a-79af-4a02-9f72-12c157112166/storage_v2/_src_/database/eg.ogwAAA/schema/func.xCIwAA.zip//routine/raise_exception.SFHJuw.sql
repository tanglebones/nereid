create function raise_exception(what character varying) returns void
  language plpgsql
as
$$
begin
  raise exception '%', what;
end
$$;

alter function raise_exception(varchar) owner to eg_dba;

grant execute on function raise_exception(varchar) to eg_app;

grant execute on function raise_exception(varchar) to eg_ro_app;

grant execute on function raise_exception(varchar) to eg_staff;

grant execute on function raise_exception(varchar) to eg_ro_staff;

