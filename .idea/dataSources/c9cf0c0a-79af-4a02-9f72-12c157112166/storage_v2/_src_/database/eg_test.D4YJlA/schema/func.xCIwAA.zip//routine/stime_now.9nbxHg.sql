create function stime_now() returns timestamp with time zone
  language plpgsql
as
$$
declare
  stime_now_text_ text;
  stime_now_inc_text_ text;
  stime_now_ timestamptz;
begin
  select current_setting('stime.now', true) into stime_now_text_;
  if stime_now_text_ is not null and stime_now_text_ != '' then
    stime_now_ = stime_now_text_ :: timestamptz;
    select current_setting('stime.now_inc', true) into stime_now_inc_text_;
    if stime_now_inc_text_ is not null and stime_now_inc_text_ != '' then
      perform set_config('stime.now', (stime_now_ + stime_now_inc_text_ :: interval) :: timestamptz :: text, false);
    end if;
    return stime_now_;
  end if;
  return now();
end;
$$;

alter function stime_now() owner to eg_test_dba;

grant execute on function stime_now() to eg_test_app;

grant execute on function stime_now() to eg_test_ro_app;

grant execute on function stime_now() to eg_test_staff;

grant execute on function stime_now() to eg_test_ro_staff;

