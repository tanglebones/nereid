create function stime_clock() returns timestamp with time zone
  language plpgsql
as
$$
declare
  stime_clock_text_ text;
  stime_clock_inc_text_ text;
  stime_clock_ timestamptz;
begin
  select current_setting('stime.clock', true) into stime_clock_text_;
  if stime_clock_text_ is not null and stime_clock_text_ != '' then
    stime_clock_ = stime_clock_text_ :: timestamptz;
    select current_setting('stime.clock_inc', true) into stime_clock_inc_text_;
    if stime_clock_inc_text_ is not null and stime_clock_inc_text_ != '' then
      perform set_config('stime.clock', (stime_clock_ + stime_clock_inc_text_ :: interval) :: timestamptz :: text,
                         false);
    end if;
    return stime_clock_;
  end if;
  return clock_timestamp();
end;
$$;

alter function stime_clock() owner to eg_dba;

grant execute on function stime_clock() to eg_app;

grant execute on function stime_clock() to eg_ro_app;

grant execute on function stime_clock() to eg_staff;

grant execute on function stime_clock() to eg_ro_staff;

