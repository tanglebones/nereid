create view pg_stat_progress_vacuum
    (pid, datid, datname, relid, phase, heap_blks_total, heap_blks_scanned, heap_blks_vacuumed, index_vacuum_count,
     max_dead_tuples, num_dead_tuples)
as
select s.pid,
  s.datid,
  d.datname,
  s.relid,
  case s.param1
    when 0 then 'initializing'::text
    when 1 then 'scanning heap'::text
    when 2 then 'vacuuming indexes'::text
    when 3 then 'vacuuming heap'::text
    when 4 then 'cleaning up indexes'::text
    when 5 then 'truncating heap'::text
    when 6 then 'performing final cleanup'::text
    else null::text
    end as phase,
  s.param2 as heap_blks_total,
  s.param3 as heap_blks_scanned,
  s.param4 as heap_blks_vacuumed,
  s.param5 as index_vacuum_count,
  s.param6 as max_dead_tuples,
  s.param7 as num_dead_tuples
from
  pg_stat_get_progress_info('VACUUM'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6, param7,
                                              param8, param9, param10, param11, param12, param13, param14, param15,
                                              param16, param17, param18, param19, param20)
    left join pg_database d on s.datid = d.oid;

alter table pg_stat_progress_vacuum
  owner to postgres;

grant select on pg_stat_progress_vacuum to public;

