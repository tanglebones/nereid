create function stuid_tz(stuid character varying) returns timestamp with time zone
  language sql
as
$$
select ('x' || substr(stuid, 1, 12))::bit(64)::bigint * interval '1 millisecond' + timestamptz 'epoch';
$$;

alter function stuid_tz(varchar) owner to eg_dba;

grant execute on function stuid_tz(varchar) to eg_app;

grant execute on function stuid_tz(varchar) to eg_ro_app;

grant execute on function stuid_tz(varchar) to eg_staff;

grant execute on function stuid_tz(varchar) to eg_ro_staff;

