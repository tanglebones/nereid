create function stuid_to_compact(stuid bytea) returns character varying
  language sql
as
$$
select
  case
    when stuid is null
      then null
    else
      replace(translate(encode(stuid, 'base64'), '/+', '-_'), '=', '')
    end;
$$;

alter function stuid_to_compact(bytea) owner to eg_dba;

grant execute on function stuid_to_compact(bytea) to eg_app;

grant execute on function stuid_to_compact(bytea) to eg_ro_app;

grant execute on function stuid_to_compact(bytea) to eg_staff;

grant execute on function stuid_to_compact(bytea) to eg_ro_staff;

