create function tuid6_from_tz(tz timestamp with time zone) returns uuid
  language sql
as
$$
select
  case
    when tz is null
      then null
    else
      (lpad(to_hex((extract(epoch from tz at time zone 'utc') * 1000) :: bigint), 12, '0') || '00000000000000000000')::uuid
    end;
$$;

alter function tuid6_from_tz(timestamp with time zone) owner to eg_dba;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_app;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_ro_app;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_staff;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_ro_staff;

