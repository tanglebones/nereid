create view pg_rules(schemaname, tablename, rulename, definition) as
select n.nspname as schemaname,
  c.relname as tablename,
  r.rulename,
  pg_get_ruledef(r.oid) as definition
from
  pg_rewrite r
    join pg_class c on c.oid = r.ev_class
    left join pg_namespace n on n.oid = c.relnamespace
where r.rulename <> '_RETURN'::name;

alter table pg_rules
  owner to postgres;

grant select on pg_rules to public;

