create function tuid6_from_tz(tz timestamp with time zone) returns uuid
  language sql
as
$$
select (lpad(to_hex((extract(epoch from tz at time zone 'utc') * 1000) :: bigint), 12, '0') || '00000000000000000000')::uuid;
$$;

alter function tuid6_from_tz(timestamp with time zone) owner to eg_test_dba;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_test_app;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_test_ro_app;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_test_staff;

grant execute on function tuid6_from_tz(timestamp with time zone) to eg_test_ro_staff;

