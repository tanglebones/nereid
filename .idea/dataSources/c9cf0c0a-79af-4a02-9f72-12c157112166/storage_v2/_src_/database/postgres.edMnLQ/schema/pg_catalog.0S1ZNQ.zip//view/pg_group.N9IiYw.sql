create view pg_group(groname, grosysid, grolist) as
select pg_authid.rolname as groname,
  pg_authid.oid as grosysid,
  array(select pg_auth_members.member
        from pg_auth_members
        where pg_auth_members.roleid = pg_authid.oid) as grolist
from pg_authid
where not pg_authid.rolcanlogin;

alter table pg_group
  owner to postgres;

grant select on pg_group to public;

