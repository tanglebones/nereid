create function min(uuid, uuid) returns uuid
  language plpgsql
as
$$
begin
  if $1 is null and $2 is null
  then
    return null;
  end if;

  if $1 is null
  then
    return $2;
  end if;

  if $2 is null
  then
    return $1;
  end if;

  if $1 > $2 then
    return $2;
  end if;

  return $1;
end;
$$;

alter function min(uuid, uuid) owner to eg_dba;

grant execute on function min(uuid, uuid) to eg_app;

grant execute on function min(uuid, uuid) to eg_ro_app;

grant execute on function min(uuid, uuid) to eg_staff;

grant execute on function min(uuid, uuid) to eg_ro_staff;

