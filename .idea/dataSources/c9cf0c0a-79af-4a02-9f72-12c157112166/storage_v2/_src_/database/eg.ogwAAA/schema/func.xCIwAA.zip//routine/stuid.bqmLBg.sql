create function stuid() returns bytea
  language plpgsql
as
$$
declare
  ct bigint;
  ret bytea;
begin
  ct := extract(epoch from clock_timestamp() at time zone 'utc') * 1000;
  ret := decode(lpad(to_hex(ct), 12, '0'), 'hex') || gen_random_bytes(26);
  return ret;
end;
$$;

alter function stuid() owner to eg_dba;

grant execute on function stuid() to eg_app;

grant execute on function stuid() to eg_ro_app;

grant execute on function stuid() to eg_staff;

grant execute on function stuid() to eg_ro_staff;

