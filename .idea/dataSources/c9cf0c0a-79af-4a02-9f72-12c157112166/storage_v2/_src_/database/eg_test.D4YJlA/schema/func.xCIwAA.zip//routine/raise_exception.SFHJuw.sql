create function raise_exception(what character varying) returns void
  language plpgsql
as
$$
begin
  raise exception '%', what;
end
$$;

alter function raise_exception(varchar) owner to eg_test_dba;

grant execute on function raise_exception(varchar) to eg_test_app;

grant execute on function raise_exception(varchar) to eg_test_ro_app;

grant execute on function raise_exception(varchar) to eg_test_staff;

grant execute on function raise_exception(varchar) to eg_test_ro_staff;

