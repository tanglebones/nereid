create function stime_today() returns date
  language plpgsql
as
$$
declare
  stime_today_text_ text;
  stime_today_inc_text_ text;
  stime_today_ date;
begin
  select current_setting('stime.today', true) into stime_today_text_;
  if stime_today_text_ is not null and stime_today_text_ != '' then
    stime_today_ = stime_today_text_ :: date;
    select current_setting('stime.today_inc', true) into stime_today_inc_text_;
    if stime_today_inc_text_ is not null and stime_today_inc_text_ != '' then
      perform set_config('stime.today', (stime_today_ + stime_today_inc_text_ :: interval) :: date :: text, false);
    end if;
    return stime_today_;
  end if;
  return current_date;
end;
$$;

alter function stime_today() owner to eg_test_dba;

grant execute on function stime_today() to eg_test_app;

grant execute on function stime_today() to eg_test_ro_app;

grant execute on function stime_today() to eg_test_staff;

grant execute on function stime_today() to eg_test_ro_staff;

