create function tz_to_iso(tz timestamp with time zone) returns character varying
  language sql
as
$$
select to_char(tz, 'YYYY-MM-DD"T"HH24:mi:ssZ')
$$;

alter function tz_to_iso(timestamp with time zone) owner to eg_dba;

grant execute on function tz_to_iso(timestamp with time zone) to eg_app;

grant execute on function tz_to_iso(timestamp with time zone) to eg_ro_app;

grant execute on function tz_to_iso(timestamp with time zone) to eg_staff;

grant execute on function tz_to_iso(timestamp with time zone) to eg_ro_staff;

