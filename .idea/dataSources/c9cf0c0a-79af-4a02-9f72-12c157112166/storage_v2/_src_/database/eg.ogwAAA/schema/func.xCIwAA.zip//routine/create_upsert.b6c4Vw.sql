create function create_upsert(schema_n character varying, table_n character varying) returns void
  language plpgsql
as
$$
declare
  unique_index_count numeric;
begin
  select count(i.relname)
  into unique_index_count
  from
    pg_index x
      join pg_class c
           on c.oid = x.indrelid
      join pg_class i
           on i.oid = x.indexrelid
      left join pg_namespace n
                on n.oid = c.relnamespace
  where ((c.relkind = any (array ['r'::char, 'm'::char])) and (i.relkind = 'i'::char))
    and x.indisunique
    and not x.indisprimary
    and n.nspname = schema_n
    and c.relname = table_n;

  if unique_index_count = 1 then
    perform create_upsert_using_unique_index_and_default_primary_key(schema_n, table_n);
  else
    perform create_upsert_using_primary_key(schema_n, table_n);
  end if;
end
$$;

alter function create_upsert(varchar, varchar) owner to eg_dba;

grant execute on function create_upsert(varchar, varchar) to eg_app;

grant execute on function create_upsert(varchar, varchar) to eg_ro_app;

grant execute on function create_upsert(varchar, varchar) to eg_staff;

grant execute on function create_upsert(varchar, varchar) to eg_ro_staff;

