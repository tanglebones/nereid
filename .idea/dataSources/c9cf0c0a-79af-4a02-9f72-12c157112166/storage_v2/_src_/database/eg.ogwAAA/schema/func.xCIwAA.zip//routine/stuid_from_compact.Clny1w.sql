create function stuid_from_compact(compact character varying) returns bytea
  language sql
as
$$
select decode(rpad(translate(compact, '-_', '/+'), 24, '='), 'base64');
$$;

alter function stuid_from_compact(varchar) owner to eg_dba;

grant execute on function stuid_from_compact(varchar) to eg_app;

grant execute on function stuid_from_compact(varchar) to eg_ro_app;

grant execute on function stuid_from_compact(varchar) to eg_staff;

grant execute on function stuid_from_compact(varchar) to eg_ro_staff;

