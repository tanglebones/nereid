create view pg_stat_database
    (datid, datname, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched,
     tup_inserted, tup_updated, tup_deleted, conflicts, temp_files, temp_bytes, deadlocks, checksum_failures,
     checksum_last_failure, blk_read_time, blk_write_time, session_time, active_time, idle_in_transaction_time,
     sessions, sessions_abandoned, sessions_fatal, sessions_killed, stats_reset)
as
select d.oid as datid,
  d.datname,
  case
    when d.oid = 0::oid then 0
    else pg_stat_get_db_numbackends(d.oid)
    end as numbackends,
  pg_stat_get_db_xact_commit(d.oid) as xact_commit,
  pg_stat_get_db_xact_rollback(d.oid) as xact_rollback,
  pg_stat_get_db_blocks_fetched(d.oid) - pg_stat_get_db_blocks_hit(d.oid) as blks_read,
  pg_stat_get_db_blocks_hit(d.oid) as blks_hit,
  pg_stat_get_db_tuples_returned(d.oid) as tup_returned,
  pg_stat_get_db_tuples_fetched(d.oid) as tup_fetched,
  pg_stat_get_db_tuples_inserted(d.oid) as tup_inserted,
  pg_stat_get_db_tuples_updated(d.oid) as tup_updated,
  pg_stat_get_db_tuples_deleted(d.oid) as tup_deleted,
  pg_stat_get_db_conflict_all(d.oid) as conflicts,
  pg_stat_get_db_temp_files(d.oid) as temp_files,
  pg_stat_get_db_temp_bytes(d.oid) as temp_bytes,
  pg_stat_get_db_deadlocks(d.oid) as deadlocks,
  pg_stat_get_db_checksum_failures(d.oid) as checksum_failures,
  pg_stat_get_db_checksum_last_failure(d.oid) as checksum_last_failure,
  pg_stat_get_db_blk_read_time(d.oid) as blk_read_time,
  pg_stat_get_db_blk_write_time(d.oid) as blk_write_time,
  pg_stat_get_db_session_time(d.oid) as session_time,
  pg_stat_get_db_active_time(d.oid) as active_time,
  pg_stat_get_db_idle_in_transaction_time(d.oid) as idle_in_transaction_time,
  pg_stat_get_db_sessions(d.oid) as sessions,
  pg_stat_get_db_sessions_abandoned(d.oid) as sessions_abandoned,
  pg_stat_get_db_sessions_fatal(d.oid) as sessions_fatal,
  pg_stat_get_db_sessions_killed(d.oid) as sessions_killed,
  pg_stat_get_db_stat_reset_time(d.oid) as stats_reset
from
  (select 0 as oid,
     null::name as datname
   union all
   select pg_database.oid,
     pg_database.datname
   from pg_database) d;

alter table pg_stat_database
  owner to postgres;

grant select on pg_stat_database to public;

