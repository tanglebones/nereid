create function tuid_zero() returns uuid
  immutable
  language sql
as
$$
select '00000000-0000-0000-0000-000000000000' :: uuid
$$;

alter function tuid_zero() owner to eg_test_dba;

grant execute on function tuid_zero() to eg_test_app;

grant execute on function tuid_zero() to eg_test_ro_app;

grant execute on function tuid_zero() to eg_test_staff;

grant execute on function tuid_zero() to eg_test_ro_staff;

