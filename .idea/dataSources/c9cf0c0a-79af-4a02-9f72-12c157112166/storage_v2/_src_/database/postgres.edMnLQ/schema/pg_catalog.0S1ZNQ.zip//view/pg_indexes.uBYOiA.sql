create view pg_indexes(schemaname, tablename, indexname, tablespace, indexdef) as
select n.nspname as schemaname,
  c.relname as tablename,
  i.relname as indexname,
  t.spcname as tablespace,
  pg_get_indexdef(i.oid) as indexdef
from
  pg_index x
    join pg_class c on c.oid = x.indrelid
    join pg_class i on i.oid = x.indexrelid
    left join pg_namespace n on n.oid = c.relnamespace
    left join pg_tablespace t on t.oid = i.reltablespace
where (c.relkind = any (array ['r'::"char", 'm'::"char", 'p'::"char"]))
  and (i.relkind = any (array ['i'::"char", 'I'::"char"]));

alter table pg_indexes
  owner to postgres;

grant select on pg_indexes to public;

