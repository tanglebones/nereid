create function tuid6() returns uuid
  language plpgsql
as
$$
declare
  r bytea;
  ts bigint;
  ret varchar;
begin
  r := func.gen_random_bytes(10);
  ts := extract(epoch from clock_timestamp() at time zone 'utc') * 1000;

  ret := lpad(to_hex(ts), 12, '0') ||
    lpad(encode(r, 'hex'), 20, '0');

  return ret :: uuid;
end;
$$;

alter function tuid6() owner to eg_test_dba;

grant execute on function tuid6() to eg_test_app;

grant execute on function tuid6() to eg_test_ro_app;

grant execute on function tuid6() to eg_test_staff;

grant execute on function tuid6() to eg_test_ro_staff;

