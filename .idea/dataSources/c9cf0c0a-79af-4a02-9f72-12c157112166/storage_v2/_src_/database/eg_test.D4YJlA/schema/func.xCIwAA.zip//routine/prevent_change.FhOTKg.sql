create function prevent_change() returns trigger
  language plpgsql
as
$$
begin
  raise exception 'Records in table % cannot be %d', tg_table_name, lower(tg_op);
end;
$$;

alter function prevent_change() owner to eg_test_dba;

grant execute on function prevent_change() to eg_test_app;

grant execute on function prevent_change() to eg_test_ro_app;

grant execute on function prevent_change() to eg_test_staff;

grant execute on function prevent_change() to eg_test_ro_staff;

