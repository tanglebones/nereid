create view pg_user_mappings(umid, srvid, srvname, umuser, usename, umoptions) as
select u.oid as umid,
  s.oid as srvid,
  s.srvname,
  u.umuser,
  case
    when u.umuser = 0::oid then 'public'::name
    else a.rolname
    end as usename,
  case
    when u.umuser <> 0::oid and a.rolname = current_user and (pg_has_role(s.srvowner, 'USAGE'::text)
      or has_server_privilege(s.oid, 'USAGE'::text)) or u.umuser = 0::oid and pg_has_role(s.srvowner, 'USAGE'::text)
      or (select pg_authid.rolsuper
          from pg_authid
          where pg_authid.rolname = current_user) then u.umoptions
    else null::text[]
    end as umoptions
from
  pg_user_mapping u
    join pg_foreign_server s on u.umserver = s.oid
    left join pg_authid a on a.oid = u.umuser;

alter table pg_user_mappings
  owner to postgres;

grant select on pg_user_mappings to public;

